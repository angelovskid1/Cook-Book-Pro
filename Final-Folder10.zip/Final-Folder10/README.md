# Recipe Finder & Meal Planner

Final project skeleton.

Features:
- PHP + MySQL (PDO) login/register
- Guest mode with localStorage
- Recipe search with culture/diet filters (hook up to real API)
- Weekly meal planner stored in localStorage
- Ingredient cart stored in DB for logged-in users
- Import from localStorage to DB after login
